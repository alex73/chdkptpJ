usb4java-javax
==============

This is an extension to usb4java and implements javax.usb using the libusb
wrapper provided by usb4java as backend.

For more detailed information please visit the [usb4java website](http://usb4java.org/).
