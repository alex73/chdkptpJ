/*
 * Copyright (C) 2013 Klaus Reimer <k@ailis.de>
 * See LICENSE.md for licensing information.
 */

/**
 * The main usb4java package.
 */
package org.usb4java.javax;
