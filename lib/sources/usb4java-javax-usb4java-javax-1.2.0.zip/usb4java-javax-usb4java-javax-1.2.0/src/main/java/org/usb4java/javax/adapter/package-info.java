/*
 * Copyright (C) 2013 Klaus Reimer <k@ailis.de>
 * See LICENSE.md for licensing information.
 */

/**
 * Event adapter classes. 
 */
package org.usb4java.javax.adapter;
