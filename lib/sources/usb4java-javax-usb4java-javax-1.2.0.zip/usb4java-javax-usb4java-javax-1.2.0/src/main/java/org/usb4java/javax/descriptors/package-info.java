/*
 * Copyright (C) 2013 Klaus Reimer <k@ailis.de>
 * See LICENSE.md for licensing information.
 */

/**
 * USB Descriptor implementations.
 */
package org.usb4java.javax.descriptors;
